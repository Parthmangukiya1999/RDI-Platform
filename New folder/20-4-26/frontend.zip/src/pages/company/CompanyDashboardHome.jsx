export default function CompanyDashboardHome() {
  return (
    <div>
      <h1>Company Dashboard</h1>
      <p>Manage opportunities, applicants, and view student projects.</p>
    </div>
  );
}