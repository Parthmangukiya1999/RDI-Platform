export default function CompanyProjects() {
  return (
    <div>
      <h1>Student Projects</h1>
      <p>Browse student project ideas and proposals.</p>
    </div>
  );
}