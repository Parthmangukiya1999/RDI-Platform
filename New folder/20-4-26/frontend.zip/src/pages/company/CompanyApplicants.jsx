export default function CompanyApplicants() {
  return (
    <div>
      <h1>Applicants</h1>
      <p>Review students who applied to your opportunities.</p>
    </div>
  );
}