export default function CompanyOpportunities() {
  return (
    <div>
      <h1>Company Opportunities</h1>
      <p>Create and manage your internship, project, or job opportunities.</p>
    </div>
  );
}