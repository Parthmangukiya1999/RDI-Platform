export default function ExpertHistory() {
  return (
    <div>
      <h1>Review History</h1>
      <p>See your completed review records.</p>
    </div>
  );
}