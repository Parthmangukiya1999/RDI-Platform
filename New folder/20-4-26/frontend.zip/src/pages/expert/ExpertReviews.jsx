export default function ExpertReviews() {
  return (
    <div>
      <h1>Assigned Reviews</h1>
      <p>Review projects assigned to you.</p>
    </div>
  );
}