// import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
// import "./admin.css";

// export default function AdminLayout() {
//   const location = useLocation();
//   const navigate = useNavigate();

//   const user = JSON.parse(localStorage.getItem("user"));
//   const role = user?.role || "mentor";
//   const displayName = user?.name || "User";

//   const baseTabs = [
//     { name: "Dashboard", path: "/admin/dashboard" },
//     { name: "Review Projects", path: "/admin/reviews" },
//     { name: "Teams", path: "/admin/teams" },
//     { name: "Opportunities", path: "/admin/opportunities" },
//   ];

//   const adminOnlyTabs = [
//     { name: "Manage Users", path: "/admin/users" },
//     { name: "Settings", path: "/admin/settings" },
//   ];

//   const tabs = role === "admin" ? [...baseTabs, ...adminOnlyTabs] : baseTabs;

//   const handleLogout = () => {
//     localStorage.removeItem("token");
//     localStorage.removeItem("user");
//     localStorage.removeItem("role");
//     navigate("/login");
//   };

//   return (
//     <div className="admin-shell">
//       <aside className="admin-sidebar">
//         <div className="admin-logo">RDI Platform</div>

//         <div className="admin-role-box">
//           <div className="admin-avatar">{displayName.charAt(0).toUpperCase()}</div>
//           <div>
//             <div className="admin-name">{displayName}</div>
//             <div className="admin-role">{role.toUpperCase()}</div>
//           </div>
//         </div>

//         <nav className="admin-nav">
//           {tabs.map((tab) => (
//             <Link
//               key={tab.path}
//               to={tab.path}
//               className={`admin-nav-link ${
//                 location.pathname === tab.path ? "active" : ""
//               }`}
//             >
//               {tab.name}
//             </Link>
//           ))}
//         </nav>

//         <button className="admin-logout-btn" onClick={handleLogout}>
//           Logout
//         </button>
//       </aside>

//       <main className="admin-main">
//         <header className="admin-topbar">
//           <div>
//             <h1 className="admin-page-title">Admin Dashboard</h1>
//             <p className="admin-subtitle">
//               Manage projects, reviews, teams, and platform activity
//             </p>
//           </div>

//           <div className="admin-topbar-user">
//             <span>{displayName}</span>
//             <span className="admin-topbar-role">{role}</span>
//           </div>
//         </header>

//         <section className="admin-content">
//           <Outlet />
//         </section>
//       </main>
//     </div>
//   );
// }


import { NavLink, Outlet, useNavigate } from "react-router-dom";
import "./admin.css";

export default function AdminLayout() {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <div>
          <div className="admin-logo">RDI Admin</div>

          <div className="admin-role-box">
            <div className="admin-avatar">A</div>
            <div>
              <div className="admin-name">Admin Panel</div>
              <div className="admin-role">Mentor / Admin</div>
            </div>
          </div>

          <nav className="admin-nav">
            <NavLink to="/admin/dashboard" className="admin-nav-link">
              Dashboard
            </NavLink>
            <NavLink to="/admin/reviews" className="admin-nav-link">
              Reviews
            </NavLink>
            <NavLink to="/admin/teams" className="admin-nav-link">
              Teams
            </NavLink>
            <NavLink to="/admin/opportunities" className="admin-nav-link">
              Opportunities
            </NavLink>
            <NavLink to="/admin/users" className="admin-nav-link">
              Users
            </NavLink>
            <NavLink to="/admin/settings" className="admin-nav-link">
              Settings
            </NavLink>
          </nav>
        </div>

        <button className="admin-logout-btn" onClick={logout}>
          Logout
        </button>
      </aside>

      <main className="admin-main">
        <div className="admin-topbar">
          <div>
            <h1 className="admin-page-title">Admin Dashboard</h1>
            <p className="admin-subtitle">Manage projects, reviews, teams, and users</p>
          </div>

          <div className="admin-topbar-user">
            <span>Welcome</span>
            <span className="admin-topbar-role">Admin</span>
          </div>
        </div>

        <div className="admin-content">
          <Outlet />
        </div>
      </main>
    </div>
  );
}