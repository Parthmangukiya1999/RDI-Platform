import { NavLink, Outlet, useNavigate } from "react-router-dom";

export default function CompanyLayout() {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div style={styles.shell}>
      <aside style={styles.sidebar}>
        <div>
          <h2>Company Panel</h2>
          <nav style={styles.nav}>
            <NavLink to="/company/dashboard" style={navStyle}>
              Dashboard
            </NavLink>
            <NavLink to="/company/opportunities" style={navStyle}>
              Opportunities
            </NavLink>
            <NavLink to="/company/projects" style={navStyle}>
              Student Projects
            </NavLink>
            <NavLink to="/company/applicants" style={navStyle}>
              Applicants
            </NavLink>
          </nav>
        </div>

        <button onClick={logout} style={styles.button}>
          Logout
        </button>
      </aside>

      <main style={styles.main}>
        <Outlet />
      </main>
    </div>
  );
}

const navStyle = ({ isActive }) => ({
  display: "block",
  padding: "10px 12px",
  borderRadius: "8px",
  textDecoration: "none",
  color: "#fff",
  background: isActive ? "#2563eb" : "transparent",
});

const styles = {
  shell: {
    display: "flex",
    minHeight: "100vh",
    background: "#f5f7fb",
  },
  sidebar: {
    width: "240px",
    background: "#111827",
    color: "#fff",
    padding: "24px",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
  },
  nav: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    marginTop: "24px",
  },
  main: {
    flex: 1,
    padding: "30px",
  },
  button: {
    padding: "10px",
    border: "none",
    borderRadius: "8px",
    background: "#dc2626",
    color: "#fff",
    cursor: "pointer",
  },
};