// import express from "express";
// import {
//   createProject,
//   getMyProjects,
//   getAllProjects,
//   updateProject,
//   deleteProject,
// } from "../controllers/projectController.js";

// import authMiddleware from "../middleware/authMiddleware.js";
// import authorizeRoles from "../middleware/roleMiddleware.js";

// const router = express.Router();

// // Student routes
// router.post("/", authMiddleware, authorizeRoles("student"), createProject);
// router.get("/my-projects", authMiddleware, authorizeRoles("student"), getMyProjects);
// router.put("/:id", authMiddleware, authorizeRoles("student"), updateProject);
// router.delete("/:id", authMiddleware, authorizeRoles("student"), deleteProject);

// // Admin / Mentor routes
// router.get("/", authMiddleware, authorizeRoles("admin", "mentor"), getAllProjects);

// export default router;

// import express from "express";
// import {
//   createProject,
//   getProjects,
//   getProjectById,
//   applyToProject,
//   updateApplicationStatus,
// } from "../controllers/projectController.js";
// import { protect } from "../middleware/authMiddleware.js";

// const router = express.Router();

// // All authenticated users can view projects
// router.get("/", protect, getProjects);
// router.get("/:id", protect, getProjectById);

// // Student creates project
// router.post("/", protect, createProject);

// // Project application flow
// router.post("/:id/apply", protect, applyToProject);
// router.put("/:id/application-status", protect, updateApplicationStatus);

// export default router;


import express from "express";
import {
  createProject,
  getProjects,
  getProjectById,
  applyToProject,
  updateApplicationStatus,
} from "../controllers/projectController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// All authenticated users can view projects
router.get("/", protect, getProjects);
router.get("/:id", protect, getProjectById);

// Create a project
router.post("/", protect, createProject);

// Project application flow
router.post("/:id/apply", protect, applyToProject);
router.put("/:id/application-status", protect, updateApplicationStatus);

export default router;