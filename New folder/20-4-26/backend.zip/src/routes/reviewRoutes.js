import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import authorizeRoles from "../middleware/roleMiddleware.js";
import {
  createReviewAssignment,
  getMyAssignedReviews,
  submitReview,
} from "../controllers/reviewController.js";

const router = express.Router();

router.post("/", protect, authorizeRoles("mentor", "admin"), createReviewAssignment);
router.get("/my", protect, authorizeRoles("expert"), getMyAssignedReviews);
router.put("/:id/submit", protect, authorizeRoles("expert"), submitReview);

export default router;