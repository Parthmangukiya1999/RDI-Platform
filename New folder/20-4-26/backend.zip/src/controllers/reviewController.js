import Review from "../models/Review.js";

export const createReviewAssignment = async (req, res) => {
  try {
    const { projectId, reviewerId } = req.body;

    const review = await Review.create({
      project: projectId,
      reviewer: reviewerId,
      status: "assigned",
    });

    res.status(201).json(review);
  } catch (error) {
    res.status(500).json({ message: "Server error while assigning review", error: error.message });
  }
};

export const getMyAssignedReviews = async (req, res) => {
  try {
    const reviews = await Review.find({ reviewer: req.user._id })
      .populate("project")
      .populate("reviewer", "name email role");

    res.json(reviews);
  } catch (error) {
    res.status(500).json({ message: "Server error while fetching reviews", error: error.message });
  }
};

export const submitReview = async (req, res) => {
  try {
    const { comments, score } = req.body;

    const review = await Review.findById(req.params.id);
    if (!review) {
      return res.status(404).json({ message: "Review not found" });
    }

    review.comments = comments;
    review.score = score;
    review.status = "completed";

    await review.save();

    res.json({ message: "Review submitted", review });
  } catch (error) {
    res.status(500).json({ message: "Server error while submitting review", error: error.message });
  }
};