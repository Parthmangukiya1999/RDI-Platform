import Project from "../models/Project.js";
import User from "../models/User.js";

export const createProject = async (req, res) => {
  try {
    const {
      title,
      shortDescription,
      description,
      category,
      skills,
      deadline,
      status,
      projectType,
      members,
    } = req.body;

    if (!title || !shortDescription || !description || !category || !deadline) {
      return res.status(400).json({
        message: "Please fill all required fields",
      });
    }

    const normalizedSkills = Array.isArray(skills)
      ? skills.map((skill) => String(skill).trim()).filter(Boolean)
      : typeof skills === "string"
      ? skills
          .split(",")
          .map((skill) => skill.trim())
          .filter(Boolean)
      : [];

    const projectMembers = [
      {
        user: req.user._id,
        role: "leader",
      },
    ];

    const pendingMembers = [];

    if (projectType === "group" && Array.isArray(members)) {
      for (const memberValue of members) {
        const email = String(memberValue).trim().toLowerCase();
        if (!email) continue;

        const foundUser = await User.findOne({ email });

        if (foundUser) {
          const alreadyAdded = projectMembers.some(
            (member) => member.user.toString() === foundUser._id.toString()
          );

          if (!alreadyAdded) {
            projectMembers.push({
              user: foundUser._id,
              role: "member",
            });
          }
        } else {
          const alreadyPending = pendingMembers.some(
            (member) => member.email === email
          );

          if (!alreadyPending) {
            pendingMembers.push({ email });
          }
        }
      }
    }

    const project = await Project.create({
      title: title.trim(),
      shortDescription: shortDescription.trim(),
      description: description.trim(),
      category: category.trim(),
      skills: normalizedSkills,
      deadline,
      status: status || "Draft",
      projectType: projectType || "individual",
      createdBy: req.user._id,
      creatorRole: req.user.role,
      members: projectMembers,
      pendingMembers,
    });

    const populatedProject = await Project.findById(project._id)
      .populate("createdBy", "name email role")
      .populate("members.user", "name email role");

    return res.status(201).json({
      message: "Project created successfully",
      project: populatedProject,
    });
  } catch (error) {
    console.error("createProject error:", error);
    return res.status(500).json({
      message: "Server error while creating project",
    });
  }
};

export const getProjects = async (req, res) => {
  try {
    const projects = await Project.find()
      .populate("createdBy", "name email role")
      .populate("members.user", "name email role")
      .sort({ createdAt: -1 });

    return res.status(200).json(projects);
  } catch (error) {
    console.error("getProjects error:", error);
    return res.status(500).json({
      message: "Server error while fetching projects",
    });
  }
};

export const getProjectById = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id)
      .populate("createdBy", "name email role")
      .populate("members.user", "name email role");

    if (!project) {
      return res.status(404).json({
        message: "Project not found",
      });
    }

    return res.status(200).json(project);
  } catch (error) {
    console.error("getProjectById error:", error);
    return res.status(500).json({
      message: "Server error while fetching project",
    });
  }
};

export const applyToProject = async (req, res) => {
  return res.status(501).json({
    message: "applyToProject is not implemented yet",
  });
};

export const updateApplicationStatus = async (req, res) => {
  return res.status(501).json({
    message: "updateApplicationStatus is not implemented yet",
  });
};