import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import Login from "./pages/Login";
import Register from "./pages/Register";
import CompanyDashboard from "./pages/CompanyDashboard";
import ExpertDashboard from "./pages/ExpertDashboard";

import ProtectedRoute from "./components/Student/ProtectedRoute";

// Student
import StudentLayout from "./components/Student/StudentLayout";
import DashboardHome from "./components/Student/DashboardHome";
import MyProjects from "./components/Student/MyProjects";
import CreateProject from "./components/Student/CreateProject";
import TeamPage from "./components/Student/TeamPage";
import ReviewsPage from "./components/Student/ReviewsPage";
import OpportunitiesPage from "./components/Student/OpportunitiesPage";

// Mentor/Admin shared layout
import AdminLayout from "./components/Admin/AdminLayout";
import AdminDashboardHome from "./pages/admin/AdminDashboardHome";
import ReviewProjects from "./pages/admin/ReviewProjects";
import TeamsPage from "./pages/admin/TeamsPage";
import AdminOpportunitiesPage from "./pages/admin/OpportunitiesPage";
import ManageUsers from "./pages/admin/ManageUsers";
import SettingsPage from "./pages/admin/SettingsPage";

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} /> 
        <Route path="/register" element={<Register />} />

        {/* Student routes */}
        <Route
          path="/student"
          element={
            <ProtectedRoute allowedRole="student">
              <StudentLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<DashboardHome />} />
          <Route path="projects" element={<MyProjects />} />
          <Route path="create" element={<CreateProject />} />
          <Route path="team" element={<TeamPage />} />
          <Route path="reviews" element={<ReviewsPage />} />
          <Route path="opportunities" element={<OpportunitiesPage />} />
        </Route>

        {/* Mentor + Admin shared dashboard */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<AdminDashboardHome />} />
        </Route>
        <Route>
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<AdminDashboardHome />} />
          <Route path="reviews" element={<ReviewProjects />} />
          <Route path="teams" element={<TeamsPage />} />
          <Route path="opportunities" element={<AdminOpportunitiesPage />} />
          <Route
            path="users"
            element={
              <ProtectedRoute allowedRole="admin">
                <ManageUsers />
              </ProtectedRoute>
            }
          />
          <Route
            path="settings"
            element={
              <ProtectedRoute allowedRole="admin">
                <SettingsPage />
              </ProtectedRoute>
            }
          />
        </Route>

        {/* Other role dashboards */}
        <Route
          path="/company/dashboard"
          element={
            <ProtectedRoute allowedRole="company">
              <CompanyDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/expert/dashboard"
          element={
            <ProtectedRoute allowedRole="expert">
              <ExpertDashboard />
            </ProtectedRoute>
          }
        />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}