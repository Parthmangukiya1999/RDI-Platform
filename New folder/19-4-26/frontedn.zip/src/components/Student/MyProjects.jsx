import "./student.css";

export default function MyProjects() {
  return (
    <div className="section-card">
      <div className="filter-bar">
        <h2 className="section-title">My Projects</h2>
        <div className="filter-controls">
          <input type="text" placeholder="Search projects" className="form-input" />
          <select className="form-select">
            <option>All Status</option>
            <option>Draft</option>
            <option>In Progress</option>
            <option>Submitted</option>
            <option>Reviewed</option>
            <option>Completed</option>
          </select>
        </div>
      </div>

      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Project Title</th>
              <th>Status</th>
              <th>Members</th>
              <th>Avg Rating</th>
              <th>Last Review</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>AI Attendance Tracker</td>
              <td>In Progress</td>
              <td>4</td>
              <td>4.5 ★</td>
              <td>12 Apr 2026</td>
              <td>
                <button className="btn">View</button>
                <button className="btn">Edit</button>
                <button className="btn">Add Member</button>
              </td>
            </tr>
            <tr>
              <td>Smart Farming Analytics</td>
              <td>Submitted</td>
              <td>3</td>
              <td>4.8 ★</td>
              <td>14 Apr 2026</td>
              <td>
                <button className="btn">View</button>
                <button className="btn">Resubmit</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}