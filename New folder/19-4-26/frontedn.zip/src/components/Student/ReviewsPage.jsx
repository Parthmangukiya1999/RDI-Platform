import "./student.css";

export default function ReviewsPage() {
  return (
    <div>
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-label">Overall Rating</div>
          <div className="stat-value">4.4 ★</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Mentor Rating</div>
          <div className="stat-value">4.2 ★</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Expert Rating</div>
          <div className="stat-value">4.5 ★</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Company Rating</div>
          <div className="stat-value">4.6 ★</div>
        </div>
      </div>

      <div className="section-card">
        <h2 className="section-title">Reviews & Feedback</h2>

        <div className="review-item">
          <h4>AI Attendance Tracker — Mentor Review</h4>
          <div>Rating: 4 ★</div>
          <div>Comment: Good progress, but improve testing documentation and final presentation structure.</div>
        </div>

        <div className="review-item">
          <h4>Smart Farming Analytics — Expert Review</h4>
          <div>Rating: 5 ★</div>
          <div>Comment: Strong analytical work and good technical approach.</div>
        </div>

        <div className="review-item">
          <h4>AI Attendance Tracker — Company Review</h4>
          <div>Rating: 4 ★</div>
          <div>Comment: Practical idea with strong future potential. Improve deployment clarity.</div>
        </div>
      </div>
    </div>
  );
}