import React, { useState } from "react";
import "./student.css";

export default function CreateProject() {
  const [projectType, setProjectType] = useState("individual");
  const [members, setMembers] = useState([""]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const [formData, setFormData] = useState({
    title: "",
    shortDescription: "",
    fullDescription: "",
    category: "",
    skillsRequired: "",
    deadline: "",
    status: "Draft",
  });

  const addMemberField = () => {
    setMembers((prev) => [...prev, ""]);
  };

  const removeMemberField = (indexToRemove) => {
    setMembers((prev) => prev.filter((_, index) => index !== indexToRemove));
  };

  const updateMember = (index, value) => {
    setMembers((prev) =>
      prev.map((member, i) => (i === index ? value : member))
    );
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateForm = () => {
    if (!formData.title.trim()) return "Project title is required";
    if (!formData.shortDescription.trim()) return "Short description is required";
    if (!formData.fullDescription.trim()) return "Full description is required";
    if (!formData.category.trim()) return "Category is required";
    if (!formData.skillsRequired.trim()) return "Skills required is required";
    if (!formData.deadline) return "Deadline is required";

    if (projectType === "group") {
      const cleanMembers = members.filter((m) => m.trim() !== "");
      if (cleanMembers.length === 0) {
        return "Please add at least one team member for a group project";
      }
    }

    return "";
  };

  const handleSubmit = async (submitStatus) => {
    const validationError = validateForm();
    if (validationError) {
      setMessage(validationError);
      return;
    }

    try {
      setLoading(true);
      setMessage("");

      const token = localStorage.getItem("token");

      if (!token) {
        setMessage("User token not found. Please login again.");
        return;
      }

      const cleanMembers =
        projectType === "group"
          ? members.filter((m) => m.trim() !== "")
          : [];

      const payload = {
        title: formData.title.trim(),
        shortDescription: formData.shortDescription.trim(),
        description: formData.fullDescription.trim(),
        category: formData.category.trim(),
        skills: formData.skillsRequired
          .split(",")
          .map((skill) => skill.trim())
          .filter(Boolean),
        deadline: formData.deadline,
        status: submitStatus,
        projectType,
        members: cleanMembers,
      };

      const apiUrl = import.meta.env.VITE_API_URL;

      if (!apiUrl) {
        setMessage("VITE_API_URL is missing in frontend environment");
        return;
      }

      const res = await fetch(`${apiUrl}/api/projects`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      let data = {};
      try {
        data = await res.json();
      } catch {
        data = {};
      }

      if (!res.ok) {
        setMessage(data.message || "Failed to create project");
        return;
      }

      setMessage("Project created successfully");

      setFormData({
        title: "",
        shortDescription: "",
        fullDescription: "",
        category: "",
        skillsRequired: "",
        deadline: "",
        status: "Draft",
      });

      setProjectType("individual");
      setMembers([""]);
    } catch (error) {
      console.error("Create project error:", error);
      setMessage("Server error while creating project");
    } finally {
      setLoading(false);
    }
  };

  const isSuccess = message.toLowerCase().includes("success");

  return (
    <div className="create-grid">
      <div className="section-card">
        <h2 className="section-title">Create Project</h2>

        {message && (
          <div
            style={{
              marginBottom: "16px",
              padding: "10px 12px",
              border: "1px solid",
              borderColor: isSuccess ? "#16a34a" : "#dc2626",
              background: isSuccess ? "#f0fdf4" : "#fef2f2",
              color: isSuccess ? "#166534" : "#b91c1c",
              borderRadius: "8px",
            }}
          >
            {message}
          </div>
        )}

        <div className="form-group">
          <label>Project Title</label>
          <input
            name="title"
            value={formData.title}
            onChange={handleChange}
            className="form-input"
            placeholder="Enter project title"
          />
        </div>

        <div className="form-group">
          <label>Short Description</label>
          <input
            name="shortDescription"
            value={formData.shortDescription}
            onChange={handleChange}
            className="form-input"
            placeholder="Enter short description"
          />
        </div>

        <div className="form-group">
          <label>Full Description</label>
          <textarea
            name="fullDescription"
            rows="5"
            value={formData.fullDescription}
            onChange={handleChange}
            className="form-textarea"
            placeholder="Enter full project description"
          />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Category</label>
            <input
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="form-input"
              placeholder="Enter category"
            />
          </div>

          <div className="form-group">
            <label>Skills Required</label>
            <input
              name="skillsRequired"
              value={formData.skillsRequired}
              onChange={handleChange}
              className="form-input"
              placeholder="Example: React, Node.js, SQL"
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Deadline</label>
            <input
              type="date"
              name="deadline"
              value={formData.deadline}
              onChange={handleChange}
              className="form-input"
            />
          </div>

          <div className="form-group">
            <label>Status</label>
            <select
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="form-select"
            >
              <option value="Draft">Draft</option>
              <option value="Open for Members">Open for Members</option>
              <option value="In Progress">In Progress</option>
              <option value="Submitted">Submitted</option>
            </select>
          </div>
        </div>

        <div className="form-group">
          <label>Project Type</label>
          <div style={{ marginTop: "8px", display: "flex", gap: "16px" }}>
            <label>
              <input
                type="radio"
                name="projectType"
                checked={projectType === "individual"}
                onChange={() => setProjectType("individual")}
              />{" "}
              Individual
            </label>

            <label>
              <input
                type="radio"
                name="projectType"
                checked={projectType === "group"}
                onChange={() => setProjectType("group")}
              />{" "}
              Group
            </label>
          </div>
        </div>

        {projectType === "group" && (
          <div className="member-box">
            <h3 className="section-title">Team Members</h3>
            <p className="small-muted">
              Leader is assigned automatically to the creator.
            </p>

            {members.map((member, index) => (
              <div
                key={index}
                className="form-group"
                style={{ display: "flex", gap: "10px", alignItems: "center" }}
              >
                <input
                  value={member}
                  onChange={(e) => updateMember(index, e.target.value)}
                  placeholder="Enter registered student email"
                  className="form-input"
                />
                {members.length > 1 && (
                  <button
                    type="button"
                    className="btn"
                    onClick={() => removeMemberField(index)}
                  >
                    Remove
                  </button>
                )}
              </div>
            ))}

            <button type="button" className="btn" onClick={addMemberField}>
              + Add Member
            </button>
          </div>
        )}

        <div style={{ display: "flex", gap: "12px", marginTop: "16px" }}>
          <button
            type="button"
            className="btn"
            onClick={() => handleSubmit("Draft")}
            disabled={loading}
          >
            {loading ? "Saving..." : "Save Draft"}
          </button>

          <button
            type="button"
            className="btn btn-primary"
            onClick={() => handleSubmit("Submitted")}
            disabled={loading}
          >
            {loading ? "Submitting..." : "Submit Project"}
          </button>
        </div>
      </div>

      <div className="section-card" style={{ height: "fit-content" }}>
        <h3 className="section-title">Project Summary</h3>
        <p>
          <strong>Visibility:</strong> Student project
        </p>
        <p>
          <strong>Members:</strong> Unlimited
        </p>
        <p>
          <strong>Leader:</strong> Auto assigned
        </p>
        <p>
          <strong>Review:</strong> Mentor, Expert, Company
        </p>
        <p>
          <strong>Feedback:</strong> Mandatory star + comment
        </p>
      </div>
    </div>
  );
}