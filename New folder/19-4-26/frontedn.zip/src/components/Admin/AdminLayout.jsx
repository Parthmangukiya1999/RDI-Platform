// import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
// import "./admin.css";

// export default function AdminLayout() {
//   const location = useLocation();
//   const navigate = useNavigate();

//   const user = JSON.parse(localStorage.getItem("user"));
//   const role = user?.role || "mentor";
//   const displayName = user?.name || "User";

//   const baseTabs = [
//     { name: "Dashboard", path: "/admin/dashboard" },
//     { name: "Review Projects", path: "/admin/reviews" },
//     { name: "Teams", path: "/admin/teams" },
//     { name: "Opportunities", path: "/admin/opportunities" },
//   ];

//   const adminOnlyTabs = [
//     { name: "Manage Users", path: "/admin/users" },
//     { name: "Settings", path: "/admin/settings" },
//   ];

//   const tabs = role === "admin" ? [...baseTabs, ...adminOnlyTabs] : baseTabs;

//   const handleLogout = () => {
//     localStorage.removeItem("token");
//     localStorage.removeItem("user");
//     localStorage.removeItem("role");
//     navigate("/login");
//   };

//   return (
//     <div className="admin-shell">
//       <aside className="admin-sidebar">
//         <div className="admin-logo">RDI Platform</div>

//         <div className="admin-role-box">
//           <div className="admin-avatar">{displayName.charAt(0).toUpperCase()}</div>
//           <div>
//             <div className="admin-name">{displayName}</div>
//             <div className="admin-role">{role.toUpperCase()}</div>
//           </div>
//         </div>

//         <nav className="admin-nav">
//           {tabs.map((tab) => (
//             <Link
//               key={tab.path}
//               to={tab.path}
//               className={`admin-nav-link ${
//                 location.pathname === tab.path ? "active" : ""
//               }`}
//             >
//               {tab.name}
//             </Link>
//           ))}
//         </nav>

//         <button className="admin-logout-btn" onClick={handleLogout}>
//           Logout
//         </button>
//       </aside>

//       <main className="admin-main">
//         <header className="admin-topbar">
//           <div>
//             <h1 className="admin-page-title">Admin Dashboard</h1>
//             <p className="admin-subtitle">
//               Manage projects, reviews, teams, and platform activity
//             </p>
//           </div>

//           <div className="admin-topbar-user">
//             <span>{displayName}</span>
//             <span className="admin-topbar-role">{role}</span>
//           </div>
//         </header>

//         <section className="admin-content">
//           <Outlet />
//         </section>
//       </main>
//     </div>
//   );
// }


import { Outlet } from "react-router-dom";
import "./admin.css";

export default function AdminLayout() {
  return (
    <div>
      <h1>Admin Layout</h1>
      <Outlet />
    </div>
  );
}