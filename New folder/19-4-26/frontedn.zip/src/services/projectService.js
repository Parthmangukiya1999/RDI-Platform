import axios from "axios";

const API_URL = `${import.meta.env.VITE_API_URL}/api/projects`;

const getToken = () => localStorage.getItem("token");

const authHeaders = () => ({
  headers: {
    Authorization: `Bearer ${getToken()}`,
  },
});

export const createProject = async (projectData) => {
  const response = await axios.post(API_URL, projectData, authHeaders());
  return response.data;
};

export const getMyProjects = async () => {
  const response = await axios.get(`${API_URL}/my-projects`, authHeaders());
  return response.data;
};

export const updateProject = async (projectId, projectData) => {
  const response = await axios.put(`${API_URL}/${projectId}`, projectData, authHeaders());
  return response.data;
};

export const deleteProject = async (projectId) => {
  const response = await axios.delete(`${API_URL}/${projectId}`, authHeaders());
  return response.data;
};

export const getAllProjects = async () => {
  const response = await axios.get(API_URL, authHeaders());
  return response.data;
};

export const reviewProject = async (projectId, reviewData) => {
  const response = await axios.put(`${API_URL}/${projectId}/review`, reviewData, authHeaders());
  return response.data;
};